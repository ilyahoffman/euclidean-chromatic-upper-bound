#!/usr/bin/env python3
"""Recompute finite identities and numerical constants in the manuscript.

Only the Python standard library is used. All inequalities checked here
use rational bounds. These finite checks supplement the written proof;
they do not prove its geometric or asymptotic assertions.
"""
from fractions import Fraction as F
from math import comb, factorial, isqrt


def require(condition, message):
    if not condition:
        raise ValueError(message)


def coefficients(d):
    result, moment = [F(1)], F(1)
    for j in range(1, d//2+1):
        moment *= F(2*j-1, d+2*j-2)
        result.append(comb(d,2*j)*moment)
    return result


def beta_moment(d):
    result = F(2**d)
    for k in range(d):
        result *= F(d-1+2*k, 2*d-2+2*k)
    return result


def exp_bounds(x, n=80):
    """Positive x < n+2: exponential series and a geometric tail bound."""
    require(0 <= x < n+2, 'Exponential bound outside its domain')
    term = lower = F(1)
    for k in range(1,n+1):
        term *= x/k
        lower += term
    first_omitted = term*x/(n+1)
    upper = lower + first_omitted/(1-x/F(n+2))
    return lower,upper


def log_bounds(q, n=100):
    require(isinstance(q,int) and q>=1, 'Logarithm expects a positive integer')
    def series(x):
        z=(x-1)/(x+1)
        lower=2*sum((z**(2*j+1)/F(2*j+1) for j in range(n)),F(0))
        return lower,lower+2*z**(2*n+1)/(F(2*n+1)*(1-z*z))
    k=q.bit_length()-1
    lo2,hi2=series(F(2));lo,hi=series(F(q,2**k))
    return k*lo2+lo,k*hi2+hi


def ceil(x):
    return -(-x.numerator//x.denominator)


def check():
    for d in range(2,101):
        c=coefficients(d);md=sum(c,F(0))
        require(md==beta_moment(d),f'Two moment formulas disagree at d={d}')
        mean=sum((2*j*w for j,w in enumerate(c)),F(0))/md
        variance=sum(((2*j-mean)**2*w for j,w in enumerate(c)),F(0))/md
        require(mean==F(d,3),f'Index mean at d={d}')
        require(variance==F(4*d*(2*d-3),9*(3*d-5)),f'Index variance at d={d}')
        eta=F(1,16*d);a=(1-eta)/(1+eta)
        pd=sum((w*a**(2*j) for j,w in enumerate(c)),F(0))
        require(a**(-d)<=F(33,31)**2,f'Geometric loss at d={d}')
        require(pd/(a**d*md)<=(1+2*a**(-d))/3,f'Chord bound at d={d}')
        q=isqrt(6400*d**3)+1
        require(F(25*d,q*q)<eta*eta,f'Strict grid gap at d={d}')
        require(q*q<=81**2*d**3,f'Grid upper bound at d={d}')
    _,ehi=exp_bounds(F(1))
    require(ehi<F(11,4),'Exponential constant')
    require(F(11,4)*(1+2*F(33,31)**2)/3<3,'Finite prefactor')

    # H(t) has the sign of t^3+2t^2+4t+4-4 exp(t).
    left=F(145123141537,10**11)
    right=F(145123141538,10**11)
    def poly(t):return t**3+2*t*t+4*t+4
    _,exphi=exp_bounds(left)
    explo,_=exp_bounds(right)
    require(poly(left)>4*exphi,'Left endpoint of the positive-root bracket')
    require(poly(right)<4*explo,'Right endpoint of the positive-root bracket')

    # At the critical point G(t)=3t/(2 exp(t)); this expression decreases for t>1.
    loexp,hiexp=exp_bounds(right)
    glow=3*right/(2*hiexp)
    loexp,hiexp=exp_bounds(left)
    ghigh=3*left/(2*loexp)
    require(F(5099952539,10**10)<glow<ghigh<F(5099952540,10**10),
            'Displayed value of G_*')
    sqrtlo=F(isqrt(2*10**40),10**20);sqrthi=sqrtlo+F(1,10**20)
    require(sqrtlo*sqrtlo<2<sqrthi*sqrthi,'Square-root bracket')
    require(F(184866238,10**8)<2*sqrtlo/(3*ghigh) and 2*sqrthi/(3*glow)<F(184866239,10**8),
            'Displayed leading constant')
    elo,ehi=exp_bounds(F(3,2))
    explicitlo=2*sqrtlo/(8-29/ehi)
    explicithi=2*sqrthi/(8-29/elo)
    require(F(184958162,10**8)<explicitlo<explicithi<F(184958163,10**8),
            'Displayed leading constant at tau=3/2')

    print('Spherical/beta moments and index identities, d=2,...,100: PASS')
    print('Chord, geometric-loss, and strict grid inequalities: PASS')
    print('Rational enclosures of tau_*, G_*, and 2 sqrt(2)/(3 G_*): PASS')
    print('Certified minima of the two closed finite bounds:')
    for d in (2,3,4,5,10,20,50,100):
        log81=log_bounds(81);logd=log_bounds(d);log384=log_bounds(384)
        bounds=[3*(1+d*min(log81[i]+F(3,2)*logd[i],log384[i]+logd[i]))
                *2**d*beta_moment(d) for i in (0,1)]
        require(ceil(bounds[0])==ceil(bounds[1]),f'Finite-bound ceiling at d={d}')
        print(f'  d={d}: {ceil(bounds[1])}')


if __name__=='__main__':
    check()
