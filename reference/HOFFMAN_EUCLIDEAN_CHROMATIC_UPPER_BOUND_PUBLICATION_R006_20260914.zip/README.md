# An upper bound for the chromatic number of Euclidean space

Author: Ilya Hoffman  
Email: ilya.hoffman@gmail.com

The manuscript proves an upper bound with exponential base 3 sqrt(3)/2 for periodic Borel colorings avoiding unit distance. It includes bounds for every dimension, a geometric figure, and an appendix on the optimal expected density of the stated Poisson construction. Choosing a smaller-volume period lattice gives the leading factor (1.84866238... + o(1)) d log d.

## Files

- `hoffman-euclidean-chromatic-upper-bound.pdf`: manuscript.
- `hoffman-euclidean-chromatic-upper-bound.tex`: complete LaTeX source, including both vector figures.
- `check_moments.py`: exact finite identities and rational enclosures for displayed constants.
- `check_planar_geometry.py`: exact checks of the added planar-area interpretation and illustration.
- `REVISION_NOTES.md`: scope of the R006 editorial revision and verification record.
- `MANIFEST.sha256`: checksums of these files.

## Build

Use a TeX installation providing AMS classes, Latin Modern, microtype, TikZ, and hyperref:

```bash
pdflatex -no-shell-escape -interaction=nonstopmode -halt-on-error hoffman-euclidean-chromatic-upper-bound.tex
pdflatex -no-shell-escape -interaction=nonstopmode -halt-on-error hoffman-euclidean-chromatic-upper-bound.tex
```

## Supplementary calculations

Python 3; no external Python packages are needed:

```bash
python3 check_moments.py
python3 check_planar_geometry.py
```

The proof is in the manuscript. Finite checks do not establish its geometric or asymptotic assertions. The appendix's optimality statement concerns the expected density in its specified random model.

The abstract identifies the work as AI-assisted research. The declaration before the references describes the tools used and their roles in mathematical development and manuscript preparation.
