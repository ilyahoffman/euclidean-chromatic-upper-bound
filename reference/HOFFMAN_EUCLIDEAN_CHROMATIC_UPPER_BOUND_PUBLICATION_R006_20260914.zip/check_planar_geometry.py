#!/usr/bin/env python3
"""Exact checks of the planar-area identity and Figure 2 coordinates.

Only Python's standard library is used. Values are represented as
a + b*sqrt(m), with rational a and b; no floating-point tolerances occur.
These checks concern the added illustration, not a new audit of the paper.
"""
from fractions import Fraction as F


def require(condition, message):
    if not condition:
        raise ValueError(message)


def add(x, y):
    return (x[0] + y[0], x[1] + y[1])


def neg(x):
    return (-x[0], -x[1])


def sub(x, y):
    return add(x, neg(y))


def mul(x, y, m):
    return (x[0]*y[0] + m*x[1]*y[1], x[0]*y[1] + x[1]*y[0])


def q(a=0, b=0):
    return (F(a), F(b))


def norm2(p, m):
    return add(mul(p[0], p[0], m), mul(p[1], p[1], m))


def distance2(p, r, m):
    return norm2((sub(p[0], r[0]), sub(p[1], r[1])), m)


def signed_area(poly, m):
    total = q()
    for p, r in zip(poly, poly[1:] + poly[:1]):
        total = add(total, sub(mul(p[0], r[1], m), mul(p[1], r[0], m)))
    return (total[0]/2, total[1]/2)


def polynomial_product(p, r):
    out = [F(0)]*(len(p) + len(r) - 1)
    for i, x in enumerate(p):
        for j, y in enumerate(r):
            out[i+j] += x*y
    return out


def check():
    # 27/16 - (1+u)^2(1-u^2)
    # = (2u-1)^2(4u^2+12u+11)/16.
    # The last quadratic is 4(u+3/2)^2+2, hence strictly positive.
    squared_area = polynomial_product([1, 2, 1], [1, 0, -1])
    lhs = [-F(x) for x in squared_area]
    lhs[0] += F(27, 16)
    rhs = [x/16 for x in polynomial_product([1, -4, 4], [11, 12, 4])]
    require(lhs == rhs, 'Exact maximum-area polynomial identity')

    # Figure 2(a): u=1/4 and sqrt(1-u^2)=sqrt(15)/4.
    left = [(q(-1), q()), (q(F(1, 4)), q(0, F(1, 4))),
            (q(F(1, 4)), q(0, -F(1, 4)))]
    require(all(norm2(p, 15) == q(1) for p in left), 'Left vertices on the unit circle')
    require(signed_area(left, 15) == q(0, -F(5, 16)), 'Left triangle area')

    # Figure 2(b): the six exact vertices (cos(k*pi/3), sin(k*pi/3)).
    half = F(1, 2)
    hexagon = [(q(1), q()), (q(half), q(0, half)),
               (q(-half), q(0, half)), (q(-1), q()),
               (q(-half), q(0, -half)), (q(half), q(0, -half))]
    triangle = [hexagon[3], hexagon[1], hexagon[5]]
    require(all(norm2(p, 3) == q(1) for p in hexagon), 'Right vertices on the unit circle')
    require(all(distance2(p, r, 3) == q(1)
                for p, r in zip(hexagon, hexagon[1:] + hexagon[:1])), 'Unit hexagon sides')
    require(all(distance2(p, r, 3) == q(3)
                for p, r in zip(triangle, triangle[1:] + triangle[:1])), 'Equilateral triangle')
    require(signed_area(hexagon, 3) == q(0, F(3, 2)), 'Hexagon area')
    require(signed_area(triangle, 3) == q(0, -F(3, 4)), 'Maximal triangle area')
    require(neg(add(signed_area(triangle, 3), signed_area(triangle, 3)))
            == signed_area(hexagon, 3), 'Hexagon area equals twice triangle area')
    require(F(9, 20) < F(11, 20) and F(7, 20) < F(11, 20),
            'Figure 1 parameters R<h and r<h')
    print('Exact maximum-area identity: PASS')
    print('Figure 2(a), exact Q(sqrt(15)) coordinates and area: PASS')
    print('Figure 2(b), exact Q(sqrt(3)) coordinates, sides and areas: PASS')
    print('Figure 1 parameter inequalities: PASS')


if __name__ == '__main__':
    check()
